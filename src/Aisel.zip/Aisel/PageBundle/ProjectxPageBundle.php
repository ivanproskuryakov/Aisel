<?php

namespace Projectx\PageBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProjectxPageBundle extends Bundle
{
}
