<?php

namespace Projectx\NavigationBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProjectxNavigationBundle extends Bundle
{
}
