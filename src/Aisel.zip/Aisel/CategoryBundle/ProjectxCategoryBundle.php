<?php

namespace Projectx\CategoryBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProjectxCategoryBundle extends Bundle
{
}
