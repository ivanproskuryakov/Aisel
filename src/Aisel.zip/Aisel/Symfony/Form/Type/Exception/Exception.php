<?php

namespace Yavin\Symfony\Form\Type\Exception;

class Exception extends \Exception
{

}


