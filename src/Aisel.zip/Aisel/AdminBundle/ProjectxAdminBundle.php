<?php

namespace Projectx\AdminBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProjectxAdminBundle extends Bundle
{
}
